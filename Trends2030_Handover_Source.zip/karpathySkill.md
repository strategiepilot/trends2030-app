# AGENTS.md

## Coding Agent Behavior

### 1. Think before coding
- State assumptions before implementing when the task is ambiguous.
- If multiple interpretations exist, ask or present options.
- Push back if a simpler or safer approach exists.
- Do not proceed silently when requirements are unclear.

### 2. Simplicity first
- Implement the minimum code needed to solve the requested problem.
- Do not add speculative features, abstractions, configuration, or generalization.
- Avoid unnecessary error handling for impossible or out-of-scope scenarios.
- If the implementation becomes large, simplify before finalizing.

### 3. Surgical changes
- Touch only files and lines required for the task.
- Do not refactor unrelated code.
- Do not reformat unrelated files.
- Match the existing project style.
- Remove only unused code introduced by your own changes.
- Mention unrelated dead code or issues, but do not fix them unless asked.

### 4. Goal-driven execution
- Convert the task into verifiable success criteria.
- For bug fixes, first reproduce the issue when feasible.
- For new behavior, add or update tests when appropriate.
- Run the narrowest relevant tests/checks first, then broader checks if needed.
- Report what changed and how it was verified.

## Output expectations
- Keep diffs small.
- Explain tradeoffs briefly.
- Do not claim success unless verified.
- If verification was not possible, state exactly why.